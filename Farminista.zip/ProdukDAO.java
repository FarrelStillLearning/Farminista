/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
package com.mycompany.farminista;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdukDAO {
    public void tambahProduk(Produk produk) {
        // Implementasi untuk menambahkan produk ke database
    }

    public List<Produk> getAllProduk() {
        List<Produk> produkList = new ArrayList<>();
        // Implementasi untuk mengambil semua produk dari database
        return produkList;
    }
    
    public void editProduk(Produk produk) {
        
    }
    
    public void hapusProduk(Produk produk) {
        // Implementasi untuk menambahkan produk ke database
    }
    // Metode untuk hapusProduk dan editProduk
}
